-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 20, 2022 at 02:14 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `trust_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `a_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(25) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `last_login_date` date NOT NULL,
  `last_login_time` time NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `name`, `mobile`, `email`, `photo`, `user_id`, `password`, `last_login_date`, `last_login_time`) VALUES
(1, 'Param Dave ', '6356532643', 'paramdave97@gmail.com', 'new.png', 'param01', '111', '0000-00-00', '00:00:00'),
(2, 'Dixit Vithani', '7778984617', 'pateldixit590@gmail.com', 'oneplus.png', 'dixit02', '222', '0000-00-00', '00:00:00'),
(3, 'Bhaskar Zinzuvadiya', '9510305393', 'bhaskarzinzuvadiya295@gma', 'vivo.jfif', 'bhaskar03', '333', '0000-00-00', '00:00:00'),
(4, 'Uday Gadhiya', '8866229903', 'udayphp2009@gmail.com', 'samsung.jfif', 'uday04', '444', '0000-00-00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `d_id` int(3) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `d_file` varchar(100) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `documents`
--


-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE IF NOT EXISTS `donor` (
  `do_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `receipt_no` int(4) NOT NULL,
  `ammount` varchar(9) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`do_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `donor`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_title`
--

CREATE TABLE IF NOT EXISTS `event_title` (
  `e_id` int(3) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(8) NOT NULL,
  `chief_guest` text NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `event_title`
--


-- --------------------------------------------------------

--
-- Table structure for table `future_event`
--

CREATE TABLE IF NOT EXISTS `future_event` (
  `u_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `chief_guest` text NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `future_event`
--


-- --------------------------------------------------------

--
-- Table structure for table `future_project`
--

CREATE TABLE IF NOT EXISTS `future_project` (
  `pr_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `estimation` varchar(9) NOT NULL,
  PRIMARY KEY (`pr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `future_project`
--


-- --------------------------------------------------------

--
-- Table structure for table `guest_photo`
--

CREATE TABLE IF NOT EXISTS `guest_photo` (
  `gp_id` int(3) NOT NULL AUTO_INCREMENT,
  `g_title` varchar(15) NOT NULL,
  `g_photo` varchar(100) NOT NULL,
  PRIMARY KEY (`gp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `guest_photo`
--


-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE IF NOT EXISTS `inquiry` (
  `q_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` text NOT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `inquiry`
--


-- --------------------------------------------------------

--
-- Table structure for table `multipages`
--

CREATE TABLE IF NOT EXISTS `multipages` (
  `m_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `multipages`
--


-- --------------------------------------------------------

--
-- Table structure for table `past_event`
--

CREATE TABLE IF NOT EXISTS `past_event` (
  `c_id` int(3) NOT NULL AUTO_INCREMENT,
  `u_id` int(3) NOT NULL,
  `photo_1` varchar(100) NOT NULL,
  `photo_2` varchar(100) NOT NULL,
  `photo_3` varchar(100) NOT NULL,
  `video` text NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `past_event`
--


-- --------------------------------------------------------

--
-- Table structure for table `past_project`
--

CREATE TABLE IF NOT EXISTS `past_project` (
  `f_id` int(3) NOT NULL AUTO_INCREMENT,
  `pr_id` int(3) NOT NULL,
  `photo_1` varchar(100) NOT NULL,
  `photo_2` varchar(100) NOT NULL,
  `photo_3` varchar(100) NOT NULL,
  `video` text NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `past_project`
--


-- --------------------------------------------------------

--
-- Table structure for table `photo_gallery`
--

CREATE TABLE IF NOT EXISTS `photo_gallery` (
  `p_id` int(3) NOT NULL AUTO_INCREMENT,
  `photo_title` varchar(15) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `photo_gallery`
--


-- --------------------------------------------------------

--
-- Table structure for table `staff_data`
--

CREATE TABLE IF NOT EXISTS `staff_data` (
  `s_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `qualification` varchar(25) NOT NULL,
  `id_proof_type` varchar(15) NOT NULL,
  `id_proof_photo` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `staff_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `trustee's_data`
--

CREATE TABLE IF NOT EXISTS `trustee's_data` (
  `t_id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(25) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `designation` varchar(30) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `trustee's_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `video_gallery`
--

CREATE TABLE IF NOT EXISTS `video_gallery` (
  `v_id` int(3) NOT NULL AUTO_INCREMENT,
  `v_title` varchar(15) NOT NULL,
  `video_link` text NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `video_gallery`
--

